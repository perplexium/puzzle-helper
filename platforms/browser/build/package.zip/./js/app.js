var App = React.createClass({
  render: function() {
    return (
      <h1>Hello World</h1>
    );
  }
});

React(<App/>, document.body);
